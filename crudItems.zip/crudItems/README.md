# Teste Pratico VIA HUMANA

## Orientações para o teste
Para a prova técnica vamos utilizar a seguinte tarefa:

Fazer um projeto utilizando framework Laravel com as seguintes funções:
- 1- Listar itens;
- 2-Adicionar itens;
- 3-Editar itens;
- 4-Remover itens:

E enviar o teste via e-mail.
______

### --> Para o avaliador técnico. <--


