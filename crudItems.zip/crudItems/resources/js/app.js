require('../../node_modules/jquery/dist/jquery.js');
require("../../node_modules/bootstrap/dist/js/bootstrap.bundle.js")
