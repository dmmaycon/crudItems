<?php $__env->startSection('title', 'Detalhe do Item'); ?>

<?php $__env->startSection('content'); ?>
    <div class="card text-center" style="width: 18rem;">
        <img class="card-img-top" src="<?php echo e(asset('storage/' . Str::after($item->image, 'public/'))); ?>" alt="Image Item">
            <div class="card-body">
            <h5 class="card-title"><?php echo e($item->name); ?></h5>
            <p class="card-text">
               Quantidade: <?php echo e($item->quantity); ?>

            </p>
            <p class="card-text">
                <?php echo e($item->description); ?>

            </p>
        </div>
        <a class="btn btn-outline-primary btn-sm" href="<?php echo e(route('item.index')); ?>">
            <i class="fa fa-angle-left"> Voltar</i>
        </a>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dmmaycon/projects/php/laravel/crudItems/resources/views/item/show.blade.php ENDPATH**/ ?>