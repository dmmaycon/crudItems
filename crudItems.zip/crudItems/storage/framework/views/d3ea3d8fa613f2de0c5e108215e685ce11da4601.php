<?php $__env->startSection('title', 'Listagem de Itens'); ?>

<?php $__env->startSection('content'); ?>
    <a class="btn btn-outline-success btn-lg" href="<?php echo e(route('item.create')); ?>">
        <i class="fa fa-plus-square"> Novo Item </i>
    </a>
    <table class="table table-bordered">
        <thead>
            <th>ID</th>
            <th>Nome</th>
            <th>Quantidade</th>
            <th>Ações</th>
        </thead>
        <tbody>

            <?php $__empty_1 = true; $__currentLoopData = $itens; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <th><?php echo e($item->id); ?></th>
                    <th><?php echo e($item->name); ?></th>
                    <th><?php echo e($item->quantity); ?></th>
                    <th>
                        <a class="btn btn-outline-primary btn-sm" href="<?php echo e(route('item.show', $item->id)); ?>">
                            <i class="fa fa-eye" title="Visualizar"></i>
                        </a>
                        <a class="btn btn-outline-success btn-sm" href="<?php echo e(route('item.edit', $item->id)); ?>">
                            <i class="fa fa-edit" title="Editar"></i>
                        </a>
                        <form style="display: inline" action="<?php echo e(route('item.destroy', $item->id)); ?>" method="POST">
                            <?php echo e(csrf_field()); ?>

                            <?php echo e(method_field('DELETE')); ?>


                            <button onclick="return confirm(`Deseja realmente excluir o item com código: <?php echo e($item->id); ?> de nome: <?php echo e($item->name); ?>`)" class="btn btn-outline-danger btn-sm" href="<?php echo e(route('item.destroy', $item->id)); ?>">
                                <i class="fa fa-trash" title="Excluir"></i>
                            </button>
                        </form>
                    </th>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td>Nenhum item cadastrado!</td>
                </tr>
            <?php endif; ?>

        </tbody>
    </table>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dmmaycon/projects/php/laravel/crudItems/resources/views/item/index.blade.php ENDPATH**/ ?>