<?php if(session('success')): ?>
  <div class="alert alert-success" role="alert">
    <?php echo session('success'); ?>

  </div>
<?php endif; ?>

<?php if(session('error')): ?>
  <div class="alert alert-danger" role="alert">
    <?php echo session('error'); ?>

  </div>
<?php endif; ?>

<?php if(session('alert')): ?>
  <div class="alert alert-primary" role="alert">
    <?php echo session('alert'); ?>

  </div>
<?php endif; ?>
<?php /**PATH /home/dmmaycon/projects/php/laravel/crudItems/resources/views/layouts/session.blade.php ENDPATH**/ ?>