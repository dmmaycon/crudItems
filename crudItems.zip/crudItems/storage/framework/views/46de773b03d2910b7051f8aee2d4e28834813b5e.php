<?php $__env->startSection('title', 'Novo Item'); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <form action="<?php echo e(route('item.store')); ?>" method="POST" enctype="multipart/form-data" class="form-horizontal">
                <?php echo e(csrf_field()); ?>

                <?php echo $__env->make('item.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </form>
            <div class="col-sm-offset-2 col-sm-10">
                <a class="btn btn-outline-primary btn-sm" href="<?php echo e(route('item.index')); ?>">
                    <i class="fa fa-angle-left"> Voltar</i>
                </a>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dmmaycon/projects/php/laravel/crudItems/resources/views/item/create.blade.php ENDPATH**/ ?>